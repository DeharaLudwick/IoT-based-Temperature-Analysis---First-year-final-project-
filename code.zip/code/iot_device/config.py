WIFI_SSID = "DSc 1"
WIFI_PASSWORD = "nicdscb1"

CLIENT_ID = "ESP32"
AWS_IOT_ENDPOINT = "a2df0otwq8tw12-ats.iot.ap-southeast-1.amazonaws.com"

PATH_TO_CERTIFICATE = "/certificates/ESP32-certificate.pem.crt"
PATH_TO_PRIVATE_KEY = "/certificates/ESP32-private.pem.key"
PATH_TO_AMAZON_ROOT_CA_1 = "/certificates/AmazonRootCA1.pem"

PUB_TOPIC = "sensors"